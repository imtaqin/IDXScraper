
export const DB_HOST = process.env.DB_HOST ?? "srv.bizmatic.id";
export const DB_PORT = process.env.DB_PORT ?? "33133";
export const DB_NAME = process.env.DB_NAME ?? "CuanScraper";
export const DB_USER = process.env.DB_USER ?? "toni";
export const DIALECT = process.env.DB_DIALECT ?? "mssql";
export const DB_PASSWORD = process.env.DB_PASSWORD ?? "OfgFUnjl5NbUhfRlr";
export const CHROME_HEADLESS = process.env.CHROME_HEADLESS ?? false;